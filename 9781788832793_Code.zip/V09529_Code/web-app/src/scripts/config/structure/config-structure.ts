﻿export interface ConfigStructure {
    serverUrl: string;
    date: {
        longFormat: string;
        shortFormat: string;
    };
}
