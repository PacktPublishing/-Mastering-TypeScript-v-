﻿export interface SelectInputOption {
    text: string;
    value: string;
}
