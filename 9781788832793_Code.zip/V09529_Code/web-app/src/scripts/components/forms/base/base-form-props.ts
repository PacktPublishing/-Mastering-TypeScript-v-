﻿export interface BaseFormProps {
    onSubmit?: () => void;
}
